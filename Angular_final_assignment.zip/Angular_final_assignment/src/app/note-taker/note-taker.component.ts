import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {

  note: Note;
  errMessage: string;
  states: Array<string> = ['not-started', 'started', 'completed'];
  categoryList: Array<string> = ['Personal', 'Professional'];
  reminderList: Array<string> = ['Daily', 'Weekly', 'Monthly'];
  @ViewChild("noteTakerForm") noteTakerForm;

  constructor(private noteService: NotesService) {
    this.note = new Note();
  }

  ngOnInit() {
    this.note = new Note();
  }

  takeNote() {
    if(this.noteTakerForm && this.noteTakerForm.valid) {
      this.errMessage = '';
      this.noteService.addNote(this.note).subscribe(addedNote => {
          this.note = new Note();
        },
        error => {
          this.errMessage = 'Http failure response for http://localhost:3000/api/v1/notes: 404 Not Found';
        }
      );
      this.note = new Note();
      this.noteTakerForm.resetForm();
    } else {
      this.errMessage = 'Please enter all required fields.';
    }
  }

}
