import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service'

@Injectable()
export class ReminderService {

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) { }

  getAllReminders() {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.get('http://localhost:8081/api/v1/reminder', {
      headers : headers
    });
  }

  getRemindersById(reminderId) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.get('http://localhost:8081/api/v1/reminder'+reminderId, {
      headers : headers
    });
  }

  createReminder(requestParams) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.post('http://localhost:8081/api/v1/reminder', requestParams, {
      headers : headers
    });
  }

  deleteReminder(reminderId) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.delete('http://localhost:8081/api/v1/reminder/' + reminderId, {
      headers : headers
    });
  }
}
