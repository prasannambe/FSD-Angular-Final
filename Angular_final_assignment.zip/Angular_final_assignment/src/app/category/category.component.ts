import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from './../services/category.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  errorMessage: string = '';
  categoryForm: FormGroup;
  categoryList;

  constructor(private fb: FormBuilder, private categoryService: CategoryService) { }

  ngOnInit() {
    this.getAllCategoryByUserId();
  }

  getAllCategoryByUserId() {
    this.categoryForm = this.fb.group({
      categoryName: ['', Validators.required],
      categoryDescription: ['', Validators.required]
    });

    this.categoryForm.reset();

    this.categoryService.getAllCategoryByUserId().subscribe(response => {
      if(response) {
        this.categoryList = response;
      } else {
        this.errorMessage = 'We are unable to fetch user\'s note categories. Please try again later.'
      }
    }, error => {
      // this.categoryList = [{categoryName:'Category 1',categoryDescription:'Category Desc 1'},{categoryName:'Category 2',categoryDescription:'Category Desc 2'}];
      this.errorMessage = 'We are unable to fetch user\'s note categories. Please try again later.'
    });
  }
  
  createCategory(categoryForm) {
    if(categoryForm && categoryForm.valid) {
      const requestParams = categoryForm.value;
      this.errorMessage = '';

      this.categoryService.createCategory(requestParams).subscribe(response => {
        if(response && response['status'] === 'Success') {
          this.getAllCategoryByUserId();
        } else {
          this.errorMessage = 'We are unable to create the category with the entered details. Please try again later.';
        }
      }, error => {
        this.errorMessage = 'We are unable to create the category with the entered details. Please try again later.';
      });
    }
  }

  deleteCategory(category) {
    this.categoryService.deleteCategory(category.id).subscribe(response => {
      if(response && response['status'] === 'Success') {
         this.getAllCategoryByUserId();
      } else {
        this.errorMessage = 'We are unable to delete the selected category. Please try again later.';
      }
    }, error => {
      this.errorMessage = 'We are unable to delete the selected category. Please try again later.';
    });
  }
}
