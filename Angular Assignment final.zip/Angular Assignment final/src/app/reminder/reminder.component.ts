import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReminderService } from './../services/reminder.service';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {
  errorMessage: string = '';
  reminderForm: FormGroup;
  reminderList;
  reminderEditId: string = '';

  constructor(private fb: FormBuilder, private reminderService: ReminderService) { }

  ngOnInit() {
    this.getAllReminders();
  }

  getAllReminders() {
    this.reminderForm = this.fb.group({
      reminderName: ['', Validators.required],
      reminderDescription: ['', Validators.required],
      reminderType: ['', Validators.required]
    });
    
    this.reminderEditId = '';

    this.reminderService.getAllReminders().subscribe(response => {
      if(response) {
        this.reminderList = response;
      } else {
        this.reminderList = [];
        this.errorMessage = 'We are unable to fetch the created reminders. Please try again later.';
      }
    }, error => {
      this.reminderList = [{reminderId:'1234',reminderName:'Reminder 1',reminderDescription:'Reminder Desc 1',reminderType:'Reminder Type 1'},{reminderId:'12343',reminderName:'Reminder 2',reminderDescription:'Reminder Desc 2',reminderType:'Reminder Type 2'}];
      // this.reminderList = [];
      this.errorMessage = 'We are unable to fetch the created reminders. Please try again later.';
    });
  }

  createReminder(reminderForm) {
    if(reminderForm && reminderForm.valid) {
      const requestParams = reminderForm.value;
      this.errorMessage = '';
      
      this.reminderService.createReminder(requestParams).subscribe(response => {
        if(response && response['status'] === 'Success') {
          this.getAllReminders();
        } else {
          this.errorMessage = 'We are unable to create reminder with the entered details. Please try again later.';
        }
      }, error => {
        this.errorMessage = 'We are unable to create reminder with the entered details. Please try again later.';
      });
    }
  }

  deleteReminder(reminder) {
    this.errorMessage = '';

    this.reminderService.deleteReminder(reminder.reminderId).subscribe(response => {
      if(response && response['status'] === 'Success') {
        this.getAllReminders();
      } else {
        this.errorMessage = 'We are unable to delete the selected reminder. Please try again later.';
      }
    }, error => {
      this.errorMessage = 'We are unable to delete the selected reminder. Please try again later.';
    });
  }

  editReminder(reminder) {
    this.reminderEditId = reminder['reminderId'];
  
    this.reminderForm = this.fb.group({
      reminderName: [reminder.reminderName, Validators.required],
      reminderDescription: [reminder.reminderDescription, Validators.required],
      reminderType: [reminder.reminderType, Validators.required]
    });
  }

  updateReminder(reminderForm) {
    if(reminderForm && reminderForm.valid) {
      const requestParams = reminderForm.value;
      this.errorMessage = '';
      
      this.reminderService.updateReminder(requestParams, this.reminderEditId).subscribe(response => {
        if(response && response['status'] === 'Success') {
          this.getAllReminders();
        } else {
          this.errorMessage = 'We are unable to update reminder with the entered details. Please try again later.';
        }
      }, error => {
        this.errorMessage = 'We are unable to update reminder with the entered details. Please try again later.';
      });
    }
  }
}
