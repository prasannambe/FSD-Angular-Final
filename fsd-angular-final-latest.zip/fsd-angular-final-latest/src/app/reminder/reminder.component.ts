import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReminderService } from './../services/reminder.service';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {
  errorMessage: string = '';
  reminderForm: FormGroup;
  reminderList;

  constructor(private fb: FormBuilder, private reminderService: ReminderService) { }

  ngOnInit() {
    this.reminderForm = this.fb.group({
      reminderName: ['', Validators.required],
      reminderDescription: ['', Validators.required],
      reminderType: ['', Validators.required]
    });

    this.getAllReminders();
  }

  getAllReminders() {
    this.reminderService.getAllReminders().subscribe(response => {
      if(response) {
        this.reminderList = response;
      } else {
        this.errorMessage = 'We are unable to fetch the created reminders. Please try again later.';
      }
    }, error => {
      this.reminderList = [{reminderName:'Reminder 1',reminderDescription:'Reminder Desc 1',reminderType:'Reminder Type 1'},{reminderName:'Reminder 2',reminderDescription:'Reminder Desc 2',reminderType:'Reminder Type 2'}];
      this.errorMessage = 'We are unable to fetch the created reminders. Please try again later.';
    });
  }

  createReminder(reminderForm) {
    if(reminderForm && reminderForm.valid) {
      const requestParams = reminderForm.value;
      this.errorMessage = '';
      
      this.reminderService.createReminder(requestParams).subscribe(response => {
        if(response) {
          this.getAllReminders();
        } else {
          this.errorMessage = 'We are unable to create reminder with the entered details. Please try again later.';
        }
      }, error => {
        this.errorMessage = 'We are unable to create reminder with the entered details. Please try again later.';
      });
    }
  }

  deleteReminder(reminder) {
    this.reminderService.deleteReminder(reminder.id).subscribe(response => {
      if(response) {
        this.getAllReminders();
      } else {
        this.errorMessage = 'We are unable to delete the selected reminder. Please try again later.';
      }
    }, error => {
      this.errorMessage = 'We are unable to delete the selected reminder. Please try again later.';
    });
  }
}
