export class Note {
  id: Number;
  title: string;
  text: string;
  state: string;
  categoryName: string;
  categoryDesc: string;
  reminderName: string;
  reminderDesc: string;
  reminderType: string;

  constructor() {
    this.title = '';
    this.text = '';
    this.state = 'not-started';
    this.categoryName = '';
    this.categoryDesc = '';
    this.reminderName = '';
    this.reminderDesc = '';
    this.reminderType = '';
  }
}
