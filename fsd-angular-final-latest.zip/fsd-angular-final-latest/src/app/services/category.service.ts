import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service'

@Injectable()
export class CategoryService {

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) { }

  getAllCategoryByUserId() {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.get('http://localhost:8082/api/v1/category', {
      headers : headers
    });
  }

  createCategory(requestParams) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.post('http://localhost:8082/api/v1/category', requestParams, {
      headers : headers
    });
  }

  deleteCategory(categoryId) {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.delete('http://localhost:8082/api/v1/category/' + categoryId, {
      headers : headers
    });
  }
}
